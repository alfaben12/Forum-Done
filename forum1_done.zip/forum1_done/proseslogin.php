<?php 

session_start(); 
$username = $_POST['username']; 
$password = $_POST['password']; 

include("config.php"); 

if (empty($username) || empty($password)) 
    { 
        header("location:login.php?status=Maaf, semua field harus diisi"); 
    } 
else{ 
$sql = "SELECT * FROM tabel_member WHERE username = '$username' AND password = '$password'"; 

$hasil = mysqli_query( $koneksi, $sql); 
$record = mysqli_fetch_array($hasil); 


if($record['username'] == ""){ 
     
    header("location:login.php?status=Maaf, username dan password tidak valid"); 
    exit(); 
    } 

if($record['username']){ 
    $_SESSION['username'] = $username; 
    header ("location:index.php"); 
     
    } 
} 
  ?>