<?php 
$password        = $_POST['password']; 
$username        = $_POST['username']; 
include("config.php"); 

if (empty($password) || empty($username)) 
    { 
        header("location:gantipass.php?status=Maaf, Anda belum memasukan password baru Anda."); 
    } 
else{ 

$query = mysqli_fetch_array(mysqli_query($GLOBALS["___mysqli_ston"], "SELECT password FROM tabel_member WHERE username='$username'")); 
if($password == $query['password']){ 
        header("location:gantipass.php?status=Maaf, password baru tidak boleh sama dengan password Anda saat ini."); 
    } 
else { 

$sql = "UPDATE tabel_member SET password='$password' where username='$username'"; 
$hasil = mysqli_query( $koneksi, $sql); 

if($hasil){ 
    echo "<script>alert('Selamat. . . !! Update password berhasil.'); location = 'gantipass.php' </script>"; 
     
    } 
else { 
    echo "Thread gagal disimpan <br>"; 
    } 
} 
} 
 ?> 
