<?php  
session_start(); 
if(!isset($_SESSION['username'])){ 
    header("location:login.php"); 
    exit(); 
    } 

if(isset($_SESSION['username'])){ 
    $username = $_SESSION['username']; 
} 
    include "config.php"; 
    $query=mysqli_fetch_array(mysqli_query($GLOBALS["___mysqli_ston"], "select * from tabel_member where username='$username'")); 
    $query2=mysqli_fetch_array(mysqli_query($GLOBALS["___mysqli_ston"], "select * from tabel_topik where pengirim='$username'")); 



//Menghitung jumlah topik dan jumlah member 
    $query3 = mysqli_query($GLOBALS["___mysqli_ston"], "SELECT * FROM tabel_topik"); 
    $query4 = mysqli_query($GLOBALS["___mysqli_ston"], "SELECT * FROM tabel_member"); 
    $jumlah_topik = mysqli_num_rows($query3); 
    $jumlah_member = mysqli_num_rows($query4); 
//mencari total view (dilihat) 

$id_topik = $_GET['id_topik']; 
$query6=mysqli_fetch_array(mysqli_query($GLOBALS["___mysqli_ston"], "select dilihat from tabel_topik where id_topik='$id_topik'")); 
$dilihat = $query6 ['dilihat'] + 1; 
$sql2 = "UPDATE tabel_topik SET dilihat='$dilihat' WHERE id_topik='$id_topik'"; 
$hasil2 = mysqli_query( $koneksi, $sql2); 

?> 





<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd"> 
<html xmlns="http://www.w3.org/1999/xhtml"> 
<head> 
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" /> 
<title>Member Lain</title> 
<style type="text/css"> 
.putih { 
    color: #FFF; 
} 

.tabel_thread{ 
    font-family:Verdana; 
    font-size:2; 
    } 
.hijau { 
    color: green; 
} 
a { 
    text-decoration:none; 
    font-weight:bold; 
    color:#0000FF; 
    } 
.merah {    font-weight: bold; 
    color: #F00; 
} 

.merah1 {    color: #F00; 
} 
</style> 
</head> 

<body style="background-image: url('images/abs.jpg');background-repeat: no-repeat, repeat;">

<div align="center"> 
  <p><font size="6" class="merah">- Thariq Alfa -</font></p> 
  <table width="795" border="0" style="border: 2px solid gray; border-radius: 10px 10px 10px 10px; background:#fff;"> 
    <tr> 
      <td height="29" bgcolor="#000000"> <div align="right"><strong class="hijau">Anda Login Sebagai : <?php  echo $_SESSION['username']; echo " &nbsp;"?> </strong></div></td> 
    </tr> 
    <tr> 
      <td>&nbsp;</td> 
    </tr> 
    <tr> 
      <td><div align="center"> 
         
          <div align="center" style="overflow:auto; width:700px; height:250px;"> 
            <table width="100%" border="0"> 
              <tr> 
                <td width="39" bgcolor="#CCCCCC"><div align="center">#</div></td> 
                <td width="41" bgcolor="#CCCCCC"><div align="center">Avatar</div></td> 
                <td width="234" bgcolor="#CCCCCC"><div align="center"><font size="2" face="verdana">Nama Lengkap</font></div></td> 
                <td width="91" bgcolor="#CCCCCC"><div align="center"><font face="verdana" size="2">Username</font></div></td> 
                <td width="91" bgcolor="#CCCCCC"><div align="center"><font face="verdana" size="2">Jenis Kelamin</font></div></td> 
                <td width="98" bgcolor="#CCCCCC"><div align="center"><font face="verdana" size="2">Member Sejak</font></div></td> 
              </tr> 
              <?php 

$nomor = 1; 


$sql = "SELECT * FROM tabel_member ORDER by nama_lengkap"; 
$hasil=mysqli_query($koneksi, $sql); 
while($record=mysqli_fetch_array($hasil)){  

?> 
              <tr> 
                <td height="31" valign="top">&nbsp;<font face="verdana" size="2"><?php echo $nomor++; ?></font></td> 
                <td valign="top"><div align="center"><strong><img src="<?php echo $record['avatar']; ?>" alt="" width="31" height="29"/></strong></div></td> 
                <td valign="top">&nbsp;<font face="verdana" size="2"><a href="profil.php?username=<?php echo $record['username']; ?>"><?php echo $record['nama_lengkap']; ?></a></font></td> 
                <td valign="top"><div align="center"><font face="verdana" size="2"><?php echo $record['username']; ?></font></div></td> 
                <td valign="top"><div align="center"><font face="verdana" size="2"><?php echo $record['jenis_kelamin']; ?></font></div> 
                  <div align="center"><font face="verdana" size="2"></font></div></td> 
                <td valign="top"><div align="center"><font face="verdana" size="2"><?php echo $record['tanggal_daftar']; ?></font></div></td> 
              </tr> 
              <?php 
//Berhenti Looping  
} 
((is_null($___mysqli_res = mysqli_close($GLOBALS["___mysqli_ston"]))) ? false : $___mysqli_res); 
?> 
            </table> 
          </div> 
         
      </div></td> 
    </tr> 
    <tr> 
      <td><div align="right"></div></td> 
    </tr> 
    <tr> 
      <td width="785"><div align="center"> 
        <table width="694" height="28" border="0"> 
          <tr> 
            <td width="108"><div align="center"><a href="index.php"><img src="images/home.png" width="64" height="64" /></a><br /> 
              <strong>Home</strong></div></td> 
            <td width="108"><div align="center"><strong><a href="create.php"><img src="images/new.png" width="64" height="64" title="Buat Thread Baru" /></a><br />Thread Baru</strong></div></td> 
            <td width="110"><div align="center"><strong><a href="profil.php?username=<?php echo $username ?>"><img src="images/profil.png" width="64" height="64" title="Profil"/></a><br />Profil</strong></div></td> 
            <td width="123"><div align="center"><strong><a href="members.php"><img src="images/members.png" width="64" height="64"  title="Lihat Daftar Member"/></a><br />Member Lain</strong></div></td> 
            <td width="115"><div align="center"><strong><a href="gantipass.php"><img src="images/changepass.jpg" width="64" height="64" title="Ganti Password" /></a><br />Ganti Password</strong></div></td> 
            <td width="104"><div align="center"><strong><a href="logout.php"><img src="images/log_off.png" width="64" height="64" title="Keluar" /></a><br /> 
              Keluar</strong></div></td> 
            </tr> 
          </table> 
      </div></td> 
    </tr> 
    <tr> 
      <td bgcolor="#000000"><div align="center"> 
        <table width="395" border="0"> 
          <tr class="hijau"> 
            <td><div align="center" class="hijau"><strong>Total Thread : <?php echo $jumlah_topik ?></strong></div></td> 
            <td><div align="center" class="hijau"><strong>Total Member : <?php echo $jumlah_member ?></strong> </div></td> 
            </tr> 
          </table> 
      </div></td> 
    </tr> 
  </table> 
</div> 
<div style="position: fixed; bottom: 0px; left: 10px;width:110px;height:115px;"> <img src="images/asd.png" width="104" height="115" border="0" /></div> 
<div style="position: fixed; bottom: 0px; right: 10px;width:110px;height:130px;"> 
</div> 
</body> 
</html> 