-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Sep 29, 2016 at 01:51 PM
-- Server version: 10.1.10-MariaDB
-- PHP Version: 7.0.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `forum1`
--

-- --------------------------------------------------------

--
-- Table structure for table `tabel_komentar`
--

CREATE TABLE `tabel_komentar` (
  `id_balasan` int(11) NOT NULL,
  `id_topik` int(25) NOT NULL,
  `topik` varchar(255) NOT NULL,
  `penjawab` varchar(20) NOT NULL,
  `isi` text NOT NULL,
  `tanggal` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tabel_komentar`
--

INSERT INTO `tabel_komentar` (`id_balasan`, `id_topik`, `topik`, `penjawab`, `isi`, `tanggal`) VALUES
(8, 18, 'Enkripsi', 'thariq1', 'Good !!!', '2016-09-29 13:50:50'),
(9, 17, 'Criptograpy', 'thariq2', 'Bagus !!!', '2016-09-29 13:51:17');

-- --------------------------------------------------------

--
-- Table structure for table `tabel_member`
--

CREATE TABLE `tabel_member` (
  `id_member` int(11) NOT NULL,
  `username` varchar(20) NOT NULL,
  `password` varchar(50) NOT NULL,
  `nama_lengkap` varchar(30) NOT NULL,
  `email` varchar(40) NOT NULL,
  `jenis_kelamin` varchar(10) NOT NULL,
  `situs_web` varchar(1000) NOT NULL,
  `avatar` varchar(1000) NOT NULL,
  `tanggal_daftar` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tabel_member`
--

INSERT INTO `tabel_member` (`id_member`, `username`, `password`, `nama_lengkap`, `email`, `jenis_kelamin`, `situs_web`, `avatar`, `tanggal_daftar`) VALUES
(35, 'thariq1', 'aben1212', 'Thariq Alfa Benriska', 'aben1212', 'Laki-laki', '', 'avatar/default.jpg', '2016-09-29'),
(36, 'thariq2', 'aben1212', 'Thariq Alfa', 'zrav420@gmail.com', 'Laki-laki', '', 'avatar/default.jpg', '2016-09-29');

-- --------------------------------------------------------

--
-- Table structure for table `tabel_topik`
--

CREATE TABLE `tabel_topik` (
  `id_topik` int(11) NOT NULL,
  `pengirim` varchar(20) NOT NULL,
  `topik` varchar(255) NOT NULL,
  `isi` text NOT NULL,
  `dilihat` int(255) NOT NULL,
  `total_balasan` int(11) NOT NULL,
  `tanggal` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tabel_topik`
--

INSERT INTO `tabel_topik` (`id_topik`, `pengirim`, `topik`, `isi`, `dilihat`, `total_balasan`, `tanggal`) VALUES
(17, 'thariq2', 'Criptograpy', 'Cryptography adalah perhitungan matematika dengan tingkat keamanan yang sangat tinggi.', 4, 1, '2016-09-29 13:49:26'),
(18, 'thariq1', 'Enkripsi', 'Enkripsi adalah prinsip mengamankan sesuatu yang penting', 3, 1, '2016-09-29 13:50:39');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tabel_komentar`
--
ALTER TABLE `tabel_komentar`
  ADD PRIMARY KEY (`id_balasan`);

--
-- Indexes for table `tabel_member`
--
ALTER TABLE `tabel_member`
  ADD PRIMARY KEY (`id_member`);

--
-- Indexes for table `tabel_topik`
--
ALTER TABLE `tabel_topik`
  ADD PRIMARY KEY (`id_topik`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tabel_komentar`
--
ALTER TABLE `tabel_komentar`
  MODIFY `id_balasan` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT for table `tabel_member`
--
ALTER TABLE `tabel_member`
  MODIFY `id_member` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;
--
-- AUTO_INCREMENT for table `tabel_topik`
--
ALTER TABLE `tabel_topik`
  MODIFY `id_topik` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
