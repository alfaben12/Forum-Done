<?php  
session_start(); 
if(!isset($_SESSION['username'])){ 
    header("location:login.php"); 
    exit(); 
    } 

if(isset($_SESSION['username'])){ 
    $username = $_SESSION['username']; 
} 
    include "config.php"; 
    $query=mysqli_fetch_array(mysqli_query($GLOBALS["___mysqli_ston"], "select * from tabel_member where username='$username'")); 
    $query2=mysqli_fetch_array(mysqli_query($GLOBALS["___mysqli_ston"], "select * from tabel_topik where pengirim='$username'")); 

//Menghitung jumlah topik dan jumlah member 
    $query3 = mysqli_query($GLOBALS["___mysqli_ston"], "SELECT * FROM tabel_topik"); 
    $query4 = mysqli_query($GLOBALS["___mysqli_ston"], "SELECT * FROM tabel_member"); 
    $jumlah_topik = mysqli_num_rows($query3); 
    $jumlah_member = mysqli_num_rows($query4); 
//mencari total view (dilihat) 

$id_topik = $_GET['id_topik']; 
$query6=mysqli_fetch_array(mysqli_query($GLOBALS["___mysqli_ston"], "select dilihat from tabel_topik where id_topik='$id_topik'")); 
$dilihat = $query6 ['dilihat'] + 1; 
$sql2 = "UPDATE tabel_topik SET dilihat='$dilihat' WHERE id_topik='$id_topik'"; 
$hasil2 = mysqli_query( $koneksi, $sql2); 

?> 





<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd"> 
<html xmlns="http://www.w3.org/1999/xhtml"> 
<head> 
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" /> 
<title>View <?php  
//Mengambil judul topik 
$query6=mysqli_fetch_array(mysqli_query($GLOBALS["___mysqli_ston"], "select * from tabel_topik where id_topik='$id_topik'")); 
echo "&quot;" .$query6['topik']. "&quot;"?></title> 
<style type="text/css"> 
.putih { 
    color: #FFF; 
} 

.tabel_thread{ 
    font-family:Verdana; 
    font-size:2; 
    } 
.hijau { 
    color: green; 
} 
a { 
    text-decoration:none; 
    font-weight:bold; 
    color:#0000FF; 
    } 
.merah {    font-weight: bold; 
    color: #F00; 
} 

</style> 
</head> 

<body bgcolor="#000000"> 

<div align="center"> 
  <p><font size="6" class="merah">- Thariq Alfa -</font></p> 
  <table width="700" border="0" style="border: 2px solid gray; border-radius: 10px 10px 10px 10px; background:#fff;"> 
    <tr> 
      <td height="29" bgcolor="#000000"> <div align="right"><strong class="hijau">Anda Login Sebagai : <?php  echo $_SESSION['username']; echo " &nbsp;"?> </strong></div></td> 
    </tr> 
    <tr> 
      <td>&nbsp;</td> 
    </tr> 
    <tr> 
     
    <?php  
    $id_topik = $_GET['id_topik']; 
    $query5=mysqli_fetch_array(mysqli_query($GLOBALS["___mysqli_ston"], "select * from tabel_topik where id_topik='$id_topik'")); 
     
    //mencari gambar pengirim thread 
    $username = $query5['pengirim']; 
    $query7=mysqli_fetch_array(mysqli_query($GLOBALS["___mysqli_ston"], "select * from tabel_member where username='$username' ")); 
    ?> 
     
      <td height="304"> 
         
          <table width="100%" border="1" cellpadding="3" cellspacing="1" bordercolor="1" bgcolor="#FFFFFF" style="border: 2px solid gray; border-radius: 10px 10px 10px 10px; background:#fff;"> 
            <tr> 
              <td width="100%" bgcolor="#CCCCCC"><strong><img src="images/thread.png" alt="" width="22" height="22" align="left" />Dikirim <?php echo $query5['tanggal']; ?></strong></td> 
              <td width="100%" height="27" bgcolor="#CCCCCC"><div align="right"><strong># 1</strong></div></td> 
            </tr> 
            <tr> 
              <td colspan="2" valign="top" bgcolor="#FFFFFF"><p><strong><img src="<?php echo $query7['avatar']; ?>" width="50" height="50" align="left" /> <a href="profil.php?username=<?php echo $query5['pengirim']; ?>"><?php echo $query5['pengirim']; ?></a><br /> 
                  <span class="merah"><font size="3">Topik :</font><font size="3"></font></span><font size="3"> <?php echo $query5['topik']; ?><br /> 
                  </font></strong>               
                <strong><font size="3"> 
                <hr /> 
                </font></strong></p> 
<pre><?php echo $query5['isi']; ?></pre></td> 
            </tr> 
            <tr> 
              <td colspan="2" valign="top" bgcolor="#CCCCCC"><div align="right"> 
                <table width="293" border="0"> 
                  <tr> 
                    <td width="133"><div align="right"><strong><?php echo $query5['total_balasan']; ?> balasan </strong></div></td> 
                    <td width="252"><div align="right"><strong><?php echo $query5['dilihat']; ?> kali dilihat</strong></div></td> 
                  </tr> 
                </table> 
              </div></td> 
            </tr> 
          </table> 
          <div align="right"><a href="balas.php?id_topik=<?php echo $id_topik; ?>"><img src="images/reply.gif" width="72" height="26" title="Balas Thread Ini" /></a><br /> 
          </div> 
          <div align="right"></div> 
          <div align="left"><strong>Respon untuk &quot;<?php echo $query5['topik']; ?>&quot;</strong> 
            <br /> 
          </div> 
           
           
          <p> 
            <?php 

// Menampilkan komentar 
$nomor = 2; 
$sql2="SELECT * FROM tabel_komentar WHERE id_topik='$id_topik' ORDER BY tanggal DESC"; 
$result2=mysqli_query($GLOBALS["___mysqli_ston"], $sql2); 
while($rows=mysqli_fetch_array($result2)){ 
?> 
          </p> 
          <table width="100%" border="0"> 
            <tr> 
              <td bgcolor="#CCCCCC"><table width="100%" border="0"> 
                <tr> 
                  <td width="27%" valign="top">Tanggal : <?php echo $rows['tanggal']; ?></td> 
                  <td width="27%" valign="top">&nbsp;</td> 
                  <td width="27%" valign="top"><div align="right"><strong># <?php echo $nomor++; ?></strong></div></td> 
                </tr> 
                <tr> 
                  <td height="20" colspan="3" valign="top" bgcolor="#FFFFFF"><p> 
                   
                  <?php 
                  //Menyesuaikan gambar / avatar 
                  $user2 = $rows['penjawab']; 
                  $queryAvatar=mysqli_fetch_array(mysqli_query($GLOBALS["___mysqli_ston"], "select * from tabel_member where username='$user2'")); 
                   
                  ?> 
                   
                  <a href="profil.php?username=<?php echo  $rows['penjawab']; ?>" ><strong><img src="<?php echo $queryAvatar['avatar']; ?>" alt="" width="50" height="50" align="left" /></strong><?php echo $rows['penjawab']; ?></a><br /> 
                    <strong>&nbsp;&nbsp;&nbsp;&nbsp;<em>Re : <?php echo $rows['topik']; ?></em></strong><br /> 
                  </p> 
                    <hr /> 
                  <pre><?php echo $rows['isi']; ?></pre></td> 
                </tr> 
                <tr> 
                  <td height="18" colspan="3" valign="top" bgcolor="#CCCCCC">&nbsp;</td> 
                </tr> 
              </table></td> 
            </tr> 
          </table> 
  <p> 
    <?php 
} 
?> 
  </p> 
      </td> 
    </tr> 
    <tr> 
      <td><div align="right"><a href="balas.php?id_topik=<?php echo $id_topik; ?>"><img src="images/reply.gif" alt="" width="72" height="26" title="Balas Thread Ini"/></a></div></td> 
    </tr> 
    <tr> 
      <td width="735"><div align="center"> 
        <table width="694" height="28" border="0"> 
          <tr> 
            <td width="108"><div align="center"><a href="index.php"><img src="images/home.png" width="64" height="64" /></a><br /> 
              <strong>Home</strong></div></td> 
            <td width="108"><div align="center"><strong><a href="create.php"><img src="images/new.png" width="64" height="64" title="Buat Thread Baru" /></a><br />Thread Baru</strong></div></td> 
            <td width="110"><div align="center"><strong><a href="profil.php?username=<?php echo $username ?>"><img src="images/profil.png" width="64" height="64" title="Profil"/></a><br />Profil</strong></div></td> 
            <td width="123"><div align="center"><strong><a href="members.php"><img src="images/members.png" width="64" height="64"  title="Lihat Daftar Member"/></a><br />Member Lain</strong></div></td> 
            <td width="115"><div align="center"><strong><a href="gantipass.php"><img src="images/changepass.jpg" width="64" height="64" title="Ganti Password" /></a><br />Ganti Password</strong></div></td> 
            <td width="104"><div align="center"><strong><a href="logout.php"><img src="images/log_off.png" width="64" height="64" title="Keluar" /></a><br /> 
              Keluar</strong></div></td> 
            </tr> 
          </table> 
      </div></td> 
    </tr> 
    <tr> 
      <td bgcolor="#000000"><div align="center"> 
        <table width="395" border="0"> 
          <tr class="hijau"> 
            <td><div align="center" class="hijau"><strong>Total Thread : <?php echo $jumlah_topik ?></strong></div></td> 
            <td><div align="center" class="hijau"><strong>Total Member : <?php echo $jumlah_member ?></strong> </div></td> 
            </tr> 
          </table> 
      </div></td> 
    </tr> 
  </table> 
</div> 
<div style="position: fixed; bottom: 0px; left: 10px;width:110px;height:115px;"> <img src="images/asd.png" width="104" height="115" border="0" /></div> 
<div style="position: fixed; bottom: 0px; right: 10px;width:110px;height:130px;"> 
</div> 
</body> 
</html> 