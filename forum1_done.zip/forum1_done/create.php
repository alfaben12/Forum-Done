<?php  
session_start(); 
if(!isset($_SESSION['username'])){ 
    header("location:login.php"); 
    exit(); 
    } 

if(isset($_SESSION['username'])){ 
    $username = $_SESSION['username']; 
} 
    include "config.php"; 
    $query=mysqli_fetch_array(mysqli_query($GLOBALS["___mysqli_ston"], "select * from tabel_member where username='$username'")); 
    $query2=mysqli_fetch_array(mysqli_query($GLOBALS["___mysqli_ston"], "select * from tabel_topik where pengirim='$username'")); 

//Menghitung jumlah topik dan jumlah member 
    $query3 = mysqli_query($GLOBALS["___mysqli_ston"], "SELECT * FROM tabel_topik"); 
    $query4 = mysqli_query($GLOBALS["___mysqli_ston"], "SELECT * FROM tabel_member"); 
    $jumlah_topik = mysqli_num_rows($query3); 
    $jumlah_member = mysqli_num_rows($query4); 
//mencari total view (dilihat) 

$id_topik = $_GET['id_topik']; 
$query6=mysqli_fetch_array(mysqli_query($GLOBALS["___mysqli_ston"], "select dilihat from tabel_topik where id_topik='$id_topik'")); 
$dilihat = $query6 ['dilihat'] + 1; 
$sql2 = "UPDATE tabel_topik SET dilihat='$dilihat' WHERE id_topik='$id_topik'"; 
$hasil2 = mysqli_query( $koneksi, $sql2); 

?> 





<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd"> 
<html xmlns="http://www.w3.org/1999/xhtml"> 
<head> 
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" /> 
<title>Thread Baru</title> 
<style type="text/css"> 
.putih { 
    color: #FFF; 
} 

.tabel_thread{ 
    font-family:Verdana; 
    font-size:2; 
    } 
.hijau { 
    color: green; 
} 
a { 
    text-decoration:none; 
    font-weight:bold; 
    color:#0000FF; 
    } 
.merah {    font-weight: bold; 
    color: #F00; 
} 

.merah1 {    color: #F00; 
} 
</style> 
</head> 

<body style="background-image: url('images/abs.jpg');background-repeat: no-repeat, repeat;">

<div align="center"> 
<font size="6" class="merah">- Thariq Alfa-</font><br /> 
  <table width="700" border="0" style="border: 2px solid gray; border-radius: 10px 10px 10px 10px; background:#fff;"> 
    <tr> 
      <td height="29" bgcolor="#000000"> <div align="right"><strong class="hijau">Anda Login Sebagai : <?php  echo $_SESSION['username']; echo " &nbsp;"?> </strong></div></td> 
    </tr> 
    <tr> 
      <td>&nbsp;</td> 
    </tr> 
    <tr> 
     
    <?php  
    $id_topik = $_GET['id_topik']; 
    $query5=mysqli_fetch_array(mysqli_query($GLOBALS["___mysqli_ston"], "select * from tabel_topik where id_topik='$id_topik'")); 
    ?> 
     
      <td height="86"><div align="center"> 
        <div align="center"> 
          <form id="form1" name="form1" method="post" action="proses_create.php"> 
            <table width="443" border="0"> 
              <tr> 
                <td colspan="3" bgcolor="#CCCCCC"><div align="center"><strong><font face="verdana" size="5">Thread Baru</font></strong></div></td> 
              </tr> 
              <tr> 
                <td colspan="3" valign="top"><div align="center" class="merah1"> <strong> 
                  <?php  
               
               
              if(isset($_GET['status'])){ 
                  $status = $_GET['status']; 
                  } 
               else{ 
                   $status = ""; 
                   } 
               
              echo "$status"; 
               
               
              ?> 
                </strong></div></td> 
              </tr> 
              <tr> 
                <td valign="top"><strong>Username</strong></td> 
                <td valign="top"><div align="center"><strong>:</strong></div></td> 
                <td valign="top"><input name="username" type="text" id="username" value="<?php echo $username?>" readonly="readonly"  /></td> 
              </tr> 
              <tr> 
                <td width="131" valign="top"><strong>Topik</strong></td> 
                <td width="13" valign="top"><div align="center"><strong>:</strong></div></td> 
                <td width="285" valign="top"><strong> 
                  <input name="topik" type="text" maxlength="40" /> 
                  * ( Judul Thread )</strong></td> 
              </tr> 
              <tr> 
                <td valign="top"><strong>Isi</strong></td> 
                <td valign="top"><div align="center"><strong>:</strong></div></td> 
                <td valign="top"><strong> 
                  <textarea name="isi" cols="45" rows="5"></textarea> 
                </strong></td> 
              </tr> 
              <tr> 
                <td valign="top">&nbsp;</td> 
                <td valign="top">&nbsp;</td> 
                <td valign="top"><input type="submit" value="Kirim" /> 
                  &nbsp; 
                  <input type="reset" value="Hapus" /></td> 
              </tr> 
              <tr> 
                <td colspan="3" valign="top" bgcolor="#CCCCCC"><div align="center"></div></td> 
              </tr> 
            </table> 
          </form> 
        </div> 
      </div></td> 
    </tr> 
    <tr> 
      <td><div align="right"></div></td> 
    </tr> 
    <tr> 
      <td width="735"><div align="center"> 
        <table width="694" height="28" border="0"> 
          <tr> 
            <td width="108"><div align="center"><a href="index.php"><img src="images/home.png" width="64" height="64" /></a><br /> 
              <strong>Home</strong></div></td> 
            <td width="108"><div align="center"><strong><a href="create.php"><img src="images/new.png" width="64" height="64" title="Buat Thread Baru" /></a><br />Thread Baru</strong></div></td> 
            <td width="110"><div align="center"><strong><a href="profil.php?username=<?php echo $username ?>"><img src="images/profil.png" width="64" height="64" title="Profil"/></a><br />Profil</strong></div></td> 
            <td width="123"><div align="center"><strong><a href="members.php"><img src="images/members.png" width="64" height="64"  title="Lihat Daftar Member"/></a><br />Member Lain</strong></div></td> 
            <td width="115"><div align="center"><strong><a href="gantipass.php"><img src="images/changepass.jpg" width="64" height="64" title="Ganti Password" /></a><br />Ganti Password</strong></div></td> 
            <td width="104"><div align="center"><strong><a href="logout.php"><img src="images/log_off.png" width="64" height="64" title="Keluar" /></a><br /> 
              Keluar</strong></div></td> 
            </tr> 
          </table> 
      </div></td> 
    </tr> 
    <tr> 
      <td bgcolor="#000000"><div align="center"> 
        <table width="395" border="0"> 
          <tr class="hijau"> 
            <td><div align="center" class="hijau"><strong>Total Thread : <?php echo $jumlah_topik ?></strong></div></td> 
            <td><div align="center" class="hijau"><strong>Total Member : <?php echo $jumlah_member ?></strong> </div></td> 
            </tr> 
          </table> 
      </div></td> 
    </tr> 
  </table> 
</div> 
<div style="position: fixed; bottom: 0px; left: 10px;width:110px;height:115px;"> <img src="images/asd.png" width="104" height="115" border="0" /></div> 
<div style="position: fixed; bottom: 0px; right: 10px;width:110px;height:130px;">
</div> 
</body> 
</html>