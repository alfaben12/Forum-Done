<?php 

$koneksi = ($GLOBALS["___mysqli_ston"] = mysqli_connect("localhost", "root", "toor")); 
((bool)mysqli_query($koneksi, "USE " . 'forum1')); 

?>