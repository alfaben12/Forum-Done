<?php
$nama_lengkap	= $_POST['nama_lengkap'];
$username		= $_POST['username'];
$jenis_kelamin 	= $_POST['jenis_kelamin'];
$situs_web		= $_POST['situs_web'];
$avatar			= $_POST['avatar'];

$tanggal_daftar	= date("Y/m/d");

include("config.php");

//Seleksi field2 yang kosong
if (empty($nama_lengkap) || empty($username) || empty($jenis_kelamin) || empty($situs_web) || empty($avatar))
	{
		echo "<script> location = 'edit_profil.php?username=$username&status=Maaf, field tidak boleh kosong' </script>";
	}


$sql = "UPDATE tabel_member SET nama_lengkap='$nama_lengkap', username='$username', jenis_kelamin='$jenis_kelamin', situs_web='$situs_web', avatar='$avatar' WHERE username='$username' ";

$hasil = mysql_query($sql, $koneksi);

if($hasil){
echo "<script> alert('Selamat. Profil Anda berhasil di perbaharui'); location = 'profil.php?username=$username'; </script>";
}
else {
	echo "Data gagal disimpan <br>";
	}	


 ?>
