<?php 
$id_topik        = $_POST['id_topik']; 
$topik            = $_POST['topik']; 
$penjawab        = $_POST['penjawab']; 
$isi             = $_POST['isi']; 

$tanggal        = date("Y-m-d H:i:s"); 

include("config.php"); 
if (empty($isi)) 
    { 
        header("location:balas.php?id_topik=$id_topik&status=Maaf, field komentar tidak boleh kosong"); 
    } 
else{ 
$sql = "INSERT INTO tabel_komentar (id_topik, topik, penjawab,  isi, tanggal) VALUES ('$id_topik', '$topik', '$penjawab', '$isi', '$tanggal')"; 
$hasil = mysqli_query( $koneksi, $sql); 


if($hasil){ 
    echo " 
    <script> location = 'view.php?id_topik=$id_topik'; </script> 
    "; 
     
    } 
else { 
    echo "komentar gagal disimpan <br>"; 
    }     
     
$query_balasan = mysqli_query($GLOBALS["___mysqli_ston"], "SELECT id_topik FROM tabel_komentar WHERE id_topik='$id_topik'"); 
$total_balas = mysqli_num_rows($query_balasan); 
$total_balasan = $total_balas; 

//memasukan total balasan ke database 


$sql2 = "UPDATE tabel_topik SET total_balasan='$total_balasan' WHERE id_topik='$id_topik'"; 
$hasil2 = mysqli_query( $koneksi, $sql2); 

if($hasil2){ 
    echo "ok"; 
    } 
else { 
    echo "komentar gagal disimpan <br>"; 
    }     

} 
 ?> 