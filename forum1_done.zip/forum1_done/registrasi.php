<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Daftar</title>
<style type="text/css">
.putih {
	color: #FFF;
}
a {
	text-decoration:none;
	font-weight:bold;
	color:#0000FF;
	}
a:hover{
	text-decoration:underline;
	}

.merah {
	font-weight: bold;
	color: #F00;
}
.abu_abu {
	color: #999;
}
body {
	background-color: #000;
}
</style>
</head>

<body style="background-image: url('images/abs.jpg');background-repeat: no-repeat, repeat;">
<form id="form1" name="form1" method="post" action="proses_registrasi.php">
  <div align="center">
    <p>&nbsp;</p>
    <p>&nbsp;</p>
    <table width="419" height="141" border="1">
      <tr>
        <td width="372" height="135" valign="top"><table width="411" border="0">
          <tr>
            <td colspan="2" align="left" valign="top" bgcolor="#000000"><div align="center" class="putih"><strong><font size="6" face="Verdana"> Daftar</font></strong></div></td>
            </tr>
          <tr>
            <td colspan="2" align="left" valign="top"><div align="center">
            
            
              <strong>
              <span class="merah"><?php 
			  
			  
			  if(isset($_GET['status'])){
				  $status = $_GET['status'];
				  }
			   else{
				   $status = "";
				   }
			  
			  echo "$status";
			  
			  
			  ?>
              </span></strong></div></td>
            </tr>
          <tr>
            <td align="left" valign="top"><span class="putih">Nama Lengkap</span></td>
            <td align="left" valign="top"><span class="putih">
              <input name="nama_lengkap" type="text" maxlength="30" id="nama_lengkap" />
              <em>* (Max 30 Char)</em></span></td>
          </tr>
          <tr>
            <td width="111" align="left" valign="top"><span class="putih">Username</span></td>
            <td width="290" align="left" valign="top"><span class="putih">
              <input name="username" type="text" maxlength="20" /> 
              * <em>(Max 20 Char)</em></span></td>
            </tr>
          <tr>
            <td align="left" valign="top"><span class="putih">Password</span></td>
            <td align="left" valign="top"><span class="putih">
              <input name="password" type="password" maxlength="50" /> 
              * <em>(Max 50 Char)</em></span></td>
            </tr>
          <tr>
            <td align="left" valign="top"><span class="putih">Email</span></td>
            <td align="left" valign="top">
              <span class="putih">
              <input name="email" type="text" maxlength="40" />              
              * <em>(Max 40 Char)</em><strong><br />
              </strong></span></td>
          </tr>
          <tr>
            <td align="left" valign="top"><span class="putih">Jenis Kelamin</span></td>
            <td align="left" valign="top"><span class="putih">
              <input name="jenis_kelamin" type="radio" value="Laki-laki" checked="checked" />
              Laki-kaki <input name="jenis_kelamin" type="radio" value="Perempuan" />
              Perempuan *</span></td>
          </tr>
          <tr>
            <td align="left" valign="top"><input name="avatar" type="hidden" value="avatar/default.jpg" />&nbsp;</td>
            <td align="left" valign="top"><span class="putih">
              <input name="input" type="submit" value="Daftar" />
            </span></td>
          </tr>
          <tr>
            <td align="left" valign="top">&nbsp;</td>
            <td align="left" valign="top"><div align="right"><span class="putih">Sudah punya akun? Login <strong><a href="login.php">disini</a>&nbsp;&nbsp;&nbsp;</strong></span></div></td>
          </tr>
          <tr>
          <td valign="top" class="putih"><div align="right"><strong>Notice : </strong></div></td>
            <td align="left" valign="top">
            
            <marquee direction="left" class="abu_abu" onmouseover="this.stop()" onmouseout="this.start()">
            &ldquo;Website ini sebagai tugas akhir mata kuliah Pemrograman Berbasis Web II, segala informasi yang ada di website ini hanya fiktif belaka.&rdquo;
          </marquee>
            
            </td>
            </tr>
        </table></td>
      </tr>
    </table>
  </div>
</form>
</body>
</html>