<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Login</title>
<style type="text/css">
.putih {
	color: #FFF;
}
a {
	text-decoration:none;
	font-weight:bold;
	color:#0000FF;
	}
a:hover{
	text-decoration:underline;
	}

.merah {
	font-weight: bold;
	color: #F00;
}
.abu_abu {
	color: #999;
}
</style>
</head>

<body style="background-image: url('images/abs.jpg');background-repeat: no-repeat, repeat;">
<script>alert('Welcome Back'); </script>;

//proses login

<div align="right">
  <form id="form1" name="form1" method="post" action="proseslogin.php">
    <table border="0">
	
      <tr>
        <td height="27" colspan="2" valign="top"><div align="center" class="merah">
          <table width="392" border="0">
            <tr>
				<td width="192"><div align="center" class="putih"><strong><font size="6" face="Verdana"> Login </font></strong></div></td>
              </tr>
            </table>
        </div></td>
      </tr>
      <tr >
			<td height="26" colspan="2" valign="top"><div align="center">
			  <span class="merah"><strong>
				<?php 
				  
				  
				  if(isset($_GET['status'])){
					  $status = $_GET['status'];
					  }
				   else{
					   $status = "";
					   }
				  
				  echo "<blink>$status</blink>";
				  
				  
				  ?>
          </strong></span>  
          <table border="0">
            <tr>
				<td><span class="putih"><strong>Username </strong></span></td>
				<td><span class="putih"><strong>Password </strong></span></td>
			</tr>
				<td><div align="right"><span class="putih"><strong>
                <input name="username" type="text" />
              </strong></span></div></td>
              
				<td><div align="right"><span class="putih"><strong>
                <input name="password" type="password" />
              </strong></span></div></td>
              </tr>
            <tr>
				<td>&nbsp;</td>
				<td align="right"><input name="input" type="submit" value="Login" />
                <input name="input" type="reset" /></td>
              </tr>
      </table>
        </div></td>
      </tr>
      <tr>
        <td width="331" height="26" valign="top"><div align="center" class="abu_abu"><marquee scrolldelay="80" direction="left" onmouseover="this.stop()" onmouseout="this.start()">
          &ldquo;Proses Login &rdquo;          
          </marquee>
          <br />
        </div></td>
      </tr>
    </table>
  </form>
</div>

//proses registrasi

  <div align="right">
  <form id="form1" name="form1" method="post" action="proses_registrasi.php">
    <p>&nbsp;</p>
    <p>&nbsp;</p>
    <table border="0">
      <tr>
        <td width="372" height="135" valign="top"><table width="411" border="0">
          <tr>
            <td colspan="2" align="left" valign="top"><div align="center" class="putih"><strong><font size="6" face="Verdana"> Signup</font></strong></div></td>
            </tr>
          <tr>
            <td colspan="2" align="left" valign="top"><div align="center">
            
            
              <strong>
              <span class="merah"><?php 
			  
			  
			  if(isset($_GET['status'])){
				  $status = $_GET['status'];
				  }
			   else{
				   $status = "";
				   }
			  
			  echo "$status";
			  
			  
			  ?>
              </span></strong></div></td>
            </tr>
          <tr>
            <td height="30px" align="left" valign="top"><span class="putih">Nama Lengkap</span></td>
            <td align="left" valign="top"><span class="putih">
              <input name="nama_lengkap" type="text" maxlength="30" id="nama_lengkap" /></span></td>
          </tr>
          <tr>
            <td height="30px" width="333" align="left" valign="top"><span class="putih">Username</span></td>
            <td width="290" align="left" valign="top"><span  class="putih">
				<input  name="username" type="text" maxlength="20" /></span></td>
            </tr>
          <tr>
            <td height="30px" align="left" valign="top"><span class="putih">Password</span></td>
            <td align="left" valign="top"><span class="putih">
              <input name="password" type="password" maxlength="50" /> </span></td>
            </tr>
          <tr>
            <td height="30px" align="left" valign="top"><span class="putih">Email</span></td>
            <td align="left" valign="top">
              <span class="putih">
              <input name="email" type="text" maxlength="40" /><strong><br />
              </strong></span></td>
          </tr>
          <tr>
            <td height="30px" align="left" valign="top"><span class="putih">Jenis Kelamin</span></td>
            <td align="left" valign="top"><span class="putih">
              <input name="jenis_kelamin" type="radio" value="Laki-laki" checked="checked" />
              Laki-kaki <input name="jenis_kelamin" type="radio" value="Perempuan" />
              Perempuan</span></td>
          </tr>
          <tr>
            <td align="left" valign="top"><input name="avatar" type="hidden" value="avatar/default.jpg" />&nbsp;</td>
            <td align="left" valign="top"><span class="putih">
              <input name="input" type="submit" value="Daftar" />
            </span></td>
          </tr>
          <tr>
          <td valign="top" class="putih"><div align="right"></div></td>
            <td align="left" valign="top">
            
            <marquee direction="left" class="abu_abu" onmouseover="this.stop()" onmouseout="this.start()">
            &ldquo;Proses Registrasi&rdquo;
          </marquee>
            
            </td>
            </tr>
        </table></td>
      </tr>
    </table>
	</form>
  </div>
<div style="position: fixed; bottom: 0px; left: 10px;width:110px;height:130px;"> <img src="images/asd.png" border="0" /></div>
<div style="position: fixed; bottom: 430px; left: 100px;width:110px;height:130px;"> <img src="images/grafika.png" width="800px" border="0" /></div>
</body>
</html>